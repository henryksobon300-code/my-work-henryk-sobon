#!/usr/bin/env python3
"""Independent, standard-library checker. Imports neither adapter nor engine.

Checks the hypotheses of PROOF.md directly from sparse incidence columns.
This is a finite certificate checker plus a mathematical lemma, not a Lean proof.
"""
import argparse
from collections import deque
from copy import deepcopy
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def need(condition, reason):
    if not condition:
        raise ValueError(reason)


def product(x, y):
    # Separate implementation: 2**j reduced mod 5 via its length-four cycle.
    x0, x1 = x % 5, x // 5
    y0, y1 = y % 5, y // 5
    return ((x0 + (1, 2, 4, 3)[x1 % 4] * y0) % 5
            + 5 * ((x1 + y1) % 20))


def invert(g):
    j = g // 5
    return (-(g % 5) * (1, 2, 4, 3)[(-j) % 4]) % 5 + 5 * ((-j) % 20)


def xor_basis(rows):
    piv = {}
    for r in rows:
        r = set(r)
        while r:
            p = min(r)
            if p not in piv:
                piv[p] = r
                break
            r.symmetric_difference_update(piv[p])
    return piv


def reduce_set(row, piv):
    r = set(row)
    while r:
        p = min(r)
        if p not in piv:
            return r
        r.symmetric_difference_update(piv[p])
    return r


def matrices_from_columns():
    a, b = (5, 6, 36), (5, 16, 19)
    cols = {s: [set() for _ in range(1000)] for s in ("HX", "HZ")}
    for k in range(3):
        for j in range(3):
            for u in range(100):
                q = 100 * (3*k+j) + u
                cols["HX"][q] = {100*j+u, 100*j+product(invert(a[k]), u)}
                cols["HZ"][q] = {100*k+u, 100*k+product(u, b[j])}
    for u in range(100):
        for j in range(3):
            cols["HX"][900+u].update((100*j+u, 100*j+product(u, invert(b[j]))))
        for k in range(3):
            cols["HZ"][900+u].update((100*k+u, 100*k+product(a[k], u)))
    rows = {}
    for s in cols:
        rows[s] = [set() for _ in range(300)]
        for q, col in enumerate(cols[s]):
            for r in col:
                rows[s][r].add(q)
    return cols, rows


def check_no_short_cycle(adj):
    n = len(adj)
    need(all(len(ns) == 6 and u not in ns for u, ns in enumerate(adj)),
         "VV graph must be simple, loop-free, six-regular")
    need(all(u in adj[v] for u, ns in enumerate(adj) for v in ns), "not undirected")
    color = {}
    for root in range(n):
        if root in color:
            continue
        color[root] = 0
        queue = [root]
        for u in queue:
            for v in adj[u]:
                if v not in color:
                    color[v] = 1-color[u]
                    queue.append(v)
                need(color[v] != color[u], "odd cycle")
    for u in range(n):
        for v in range(u):
            need(len(adj[u] & adj[v]) <= 1, "four-cycle")
    return {"bipartite": True, "no_four_cycles": True, "girth_lower_bound": 6}


def all_distances(adj):
    result = []
    for root in range(len(adj)):
        d = [-1] * len(adj)
        d[root] = 0
        queue = [root]
        for u in queue:
            for v in adj[u]:
                if d[v] == -1:
                    d[v] = d[u] + 1
                    queue.append(v)
        result.append(d)
    return result


def permutation_cycles(p):
    need(sorted(p) == list(range(len(p))), "CC action not a permutation")
    seen, lengths = set(), []
    for s in range(len(p)):
        if s in seen:
            continue
        t, cycle = s, []
        while t not in seen:
            seen.add(t)
            cycle.append(t)
            t = p[t]
        need(t == s, "malformed permutation cycle")
        lengths.append(len(cycle))
    need(min(lengths) > 5, "CC invariant support can be too small")
    return lengths


def verify_bridge_record(record):
    need(record["function"] == "minimize_moore", "wrong engine function")
    outputs, transitions = record["arguments"]
    bridge = record["result"]
    pi, qo, qt = (bridge[k] for k in ("state_map", "quotient_outputs", "quotient_transitions"))
    need(len(pi) == len(outputs) == 100, "bad source count")
    need(set(pi) == set(range(len(qo))), "quotient not surjective")
    need(len(qt) == len(transitions), "bad alphabet size")
    for s in range(100):
        need(outputs[s] == qo[pi[s]], "quotient output mismatch")
        for j, tr in enumerate(transitions):
            need(pi[tr[s]] == qt[j][pi[s]], "bridge does not commute")
    return True


def check(out, math_only=False):
    raw = (ROOT / "inputs/1000-406-6.json").read_bytes()
    need(hashlib.sha256(raw).hexdigest() ==
         "fdc1e71bfd9a588b39f545882a93b5b316582ecdd157451bd03c7411219b842b", "input changed")
    source = json.loads(raw)
    cols, rows = matrices_from_columns()
    basis = {}
    for label, sector in (("HX", "X"), ("HZ", "Z")):
        stored = [set(row) for row in source["checks"][sector]]
        basis[sector] = xor_basis(stored)
        natural_basis = xor_basis(rows[label])
        need(len(basis[sector]) == len(natural_basis) == 297, "incorrect rank")
        need(all(not reduce_set(r, basis[sector]) for r in rows[label]), "full -> stored span failed")
        need(all(not reduce_set(r, natural_basis) for r in stored), "stored -> full span failed")
    need(1000-len(basis["X"])-len(basis["Z"]) == source["k"] == 406, "wrong k")
    need(all(len(x & z) % 2 == 0 for x in rows["HX"] for z in rows["HZ"]),
         "CSS commutation failed")
    for sector, opposite in (("X", "HZ"), ("Z", "HX")):
        w = set(source["distance"][sector]["witness"])
        need(len(w) == 6, "wrong witness weight")
        need(all(len(w & r) % 2 == 0 for r in rows[opposite]), "nonzero witness syndrome")
        need(bool(reduce_set(w, basis[sector])), "witness is a stabilizer")

    checks = {}
    for label in ("HX", "HZ"):
        graphs = [[set() for _ in range(100)] for _ in range(3)]
        for q in range(900):
            col = cols[label][q]
            need(len(col) == 2, "VV column not an edge")
            x, y = sorted(col)
            need(x//100 == y//100, "VV crosses syndrome blocks")
            graphs[x//100][x%100].add(y%100)
            graphs[x//100][y%100].add(x%100)
        cycle_checks = [check_no_short_cycle(g) for g in graphs]
        ds = [all_distances(g) for g in graphs]
        cc_actions, all_costs = [], []
        for block in range(3):
            p = []
            for u in range(100):
                support = {r%100 for r in cols[label][900+u] if r//100 == block}
                need(len(support) == 2 and u in support, "incorrect CC boundary")
                p.append(next(iter(support-{u})))
            cc_actions.append(p)
        cycle_lengths = [permutation_cycles(p) for p in cc_actions]
        for u in range(100):
            cost = [ds[b][u][cc_actions[b][u]] for b in range(3)]
            need(all(c >= 0 for c in cost), "disconnected one-CC endpoint pair")
            need(sum(cost) >= 5, "one CC plus at most four VV not excluded")
            all_costs.append(cost)
        # Independently enumerate every 2-element CC support (4,950 choices).
        forbidden_two_cc = 0
        for u in range(100):
            for v in range(u):
                pair = {u, v}
                sizes = [len(pair ^ {p[u], p[v]}) for p in cc_actions]
                need(all(s > 0 for s in sizes), "two-element invariant CC support")
                if sizes == [2, 2, 2]:
                    forbidden_two_cc += 1
        need(forbidden_two_cc == 0, "two CC plus three VV might close")
        checks[label] = {"VV_cycle_checks": cycle_checks,
                         "CC_permutation_cycle_lengths": cycle_lengths,
                         "min_exact_graph_cost_one_CC": min(map(sum, all_costs)),
                         "all_one_CC_costs": all_costs,
                         "two_CC_subsets_checked": 4950,
                         "two_CC_all_blocks_boundary_two": 0}

    # Independently recheck the complete original-engine bridge log.
    records = []
    if not math_only:
        records = [json.loads(line) for line in (out / "engine_io.jsonl").read_text().splitlines()]
        need(len(records) == 24, "missing engine calls")
        for i in range(0, 24, 2):
            verify_bridge_record(records[i])
            call = records[i+1]
            need(call["function"] == "verify_bridge" and call["result"] is True,
                 "original engine rejected bridge")
            need(call["arguments"] == records[i]["arguments"]+[records[i]["result"]],
                 "bridge verification logged with different input")

    # Meaningful negative controls: detect a wrong bridge and a bad CC orbit.
    controls = {}
    experiments = [("identity_CC_action_rejected", lambda: permutation_cycles(list(range(100))))]
    if records:
        broken = deepcopy(records[-2])
        broken["result"]["quotient_transitions"][0][0] = (
            broken["result"]["quotient_transitions"][0][0] + 1) % 20
        experiments.append(("corrupted_bridge_rejected", lambda: verify_bridge_record(broken)))
    for name, fn in experiments:
        try:
            fn()
        except ValueError:
            controls[name] = True
        else:
            raise ValueError("negative control was accepted: " + name)

    result = {"independent": True, "imports_engine_or_adapter": False,
              "matrix_row_spaces_match": True, "CSS_commutes": True,
              "ranks": {"HX": 297, "HZ": 297}, "n": 1000, "k": 406,
              "proof_hypotheses": checks, "witnesses_verified": True,
              "engine_bridges_independently_verified": len(records)//2,
              "negative_controls": controls,
              "distance_conclusion_given_lemma_in_PROOF_md": {"X": 6, "Z": 6, "total": 6}}
    out.mkdir(parents=True, exist_ok=True)
    (out / "independent_check.json").write_text(json.dumps(result, indent=2, sort_keys=True)+"\n")
    print(json.dumps({k:v for k,v in result.items() if k != "proof_hypotheses"}, indent=2))


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out", type=Path, default=ROOT / "results")
    p.add_argument("--math-only", action="store_true", help="verify mathematics without private engine source/logs")
    args = p.parse_args()
    check(args.out, args.math_only)
