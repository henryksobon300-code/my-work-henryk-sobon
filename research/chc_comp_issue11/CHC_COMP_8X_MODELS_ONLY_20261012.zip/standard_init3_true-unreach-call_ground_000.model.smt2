sat
(model
  (define-fun |main@entry| ((x0 Int)) Bool true)
  (define-fun |main@bb9.i|
    ((b Int) (i Int) (a (Array Int Int)) (lim Int)) Bool
    (and (> b 0) (> lim 0) (>= i 0) (<= i lim)))
  (define-fun |main@bb19.i|
    ((b Int) (i Int) (a (Array Int Int)) (lim Int)) Bool
    (and (> b 0) (> lim 0) (>= i 0) (<= i lim)))
  (define-fun |main@bb29.i|
    ((b Int) (i Int) (a (Array Int Int)) (lim Int)) Bool
    (and
      (> b 0) (> lim 0) (>= i 0) (<= i lim)
      (forall ((t Int))
        (=> (and (>= t 0) (< t i))
            (= (select a (+ b t)) 44)))))
  (define-fun |main@bb39.i|
    ((b Int) (a (Array Int Int)) (i Int) (lim Int)) Bool
    (and
      (> b 0) (> lim 0) (>= i 0) (<= i lim)
      (forall ((t Int))
        (=> (and (>= t 0) (< t lim))
            (= (select a (+ b t)) 44)))))
  (define-fun |main@verifier.error.split| () Bool false)
)
