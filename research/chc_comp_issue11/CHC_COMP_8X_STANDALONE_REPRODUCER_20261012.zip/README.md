# CHC-COMP standard_init2..9 — standalone model reproducer

This is a small, benchmark-specific reproducer for the eight model files posted in issue #11.
It is **not** the private discovery/search engine and it does not reproduce the historical discovery process.
It only regenerates the final eight SMT-LIB model files from the already stated invariant family.

## 1. Generate the eight model files

```bash
python3 generate_models.py --out models
```

The generated files are byte-for-byte identical to the eight candidate model files used in the successful replay.

## 2. Benchmark files

Use the exact tasks from:

`chc-comp/chc-comp26-benchmarks/quic3/data/standard_init{2..9}_true-unreach-call_ground_000.smt2`

The corresponding 2025/2026 SMT2 copies used in the replay were checked as the same tasks for this family.

## 3. Validation route used in the reproducibility run

Pinned validator lineage:

- repository: `chc-comp/chc-comp25-scripts`
- commit: `674721f1f9e5afb97528fc14a02c2afc5354c409`
- `z3-solver==4.13.3.0`
- `ply==3.11`

For one task, with `validate-model.py` from the pinned checkout:

```bash
python3 validate-model.py \
  /path/to/chc-comp26-benchmarks/quic3/data/standard_init2_true-unreach-call_ground_000.smt2 \
  < models/standard_init2_true-unreach-call_ground_000.model.smt2 \
  > validation_query.smt2
```

Then check the generated query with Z3 4.13.3:

```bash
python3 - <<'PY' < validation_query.smt2
import sys, z3
s = z3.Solver()
s.from_string(sys.stdin.read())
print(s.check())
PY
```

Expected result for every N=2..9 candidate model: `unsat`.

In the fresh replay, all 8 candidate models produced `unsat`; all 8 deliberately corrupted final-value controls produced `sat`; and 128/128 per-clause checks were `unsat`.

## What the reproducer encodes

For a task with N write loops, the final written constant is `41+N`.
Earlier write-loop relations keep only the scalar loop bounds. The last write-loop relation additionally states that the already-written prefix contains `41+N`. The verification-loop relation states that the full checked range contains `41+N`. The error relation is `false`.

That is sufficient to regenerate these eight concrete model files. It does not expose or implement the general MathemaSpace discovery machinery.

## Known open reproducibility point

A separate run by Levente using a current-validator route reportedly kept running. This package documents the pinned route that terminates and validates the models; it does not claim to explain that separate hang.
