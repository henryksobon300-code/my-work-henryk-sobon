#!/usr/bin/env python3
from pathlib import Path
import argparse, hashlib

def make_model(n: int) -> str:
    if not 2 <= n <= 9:
        raise ValueError("n must be in 2..9")
    final_value = 41 + n
    out = [
        "sat",
        "(model",
        "  (define-fun |main@entry| ((x0 Int)) Bool true)",
    ]
    for k in range(1, n + 1):
        bb = 10 * k - 1
        if k < n:
            out += [
                f"  (define-fun |main@bb{bb}.i|",
                "    ((b Int) (i Int) (a (Array Int Int)) (lim Int)) Bool",
                "    (and (> b 0) (> lim 0) (>= i 0) (<= i lim)))",
            ]
        else:
            out += [
                f"  (define-fun |main@bb{bb}.i|",
                "    ((b Int) (i Int) (a (Array Int Int)) (lim Int)) Bool",
                "    (and",
                "      (> b 0) (> lim 0) (>= i 0) (<= i lim)",
                "      (forall ((t Int))",
                "        (=> (and (>= t 0) (< t i))",
                f"            (= (select a (+ b t)) {final_value})))))",
            ]
    bb = 10 * (n + 1) - 1
    out += [
        f"  (define-fun |main@bb{bb}.i|",
        "    ((b Int) (a (Array Int Int)) (i Int) (lim Int)) Bool",
        "    (and",
        "      (> b 0) (> lim 0) (>= i 0) (<= i lim)",
        "      (forall ((t Int))",
        "        (=> (and (>= t 0) (< t lim))",
        f"            (= (select a (+ b t)) {final_value})))))",
        "  (define-fun |main@verifier.error.split| () Bool false)",
        ")",
    ]
    return "\n".join(out) + "\n"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="models")
    args = ap.parse_args()
    outdir = Path(args.out)
    outdir.mkdir(parents=True, exist_ok=True)
    for n in range(2, 10):
        name = f"standard_init{n}_true-unreach-call_ground_000.model.smt2"
        data = make_model(n).encode()
        (outdir / name).write_bytes(data)
        print(n, hashlib.sha256(data).hexdigest(), name)

if __name__ == "__main__":
    main()
