# Replay for the two [[980,398,6]] CSS codes

Run `python3 replay.py` with Python 3.10 or later. The standard library suffices.
Allow about a minute and up to 1 GiB of RAM for the exact three-edge census.

The replay reconstructs the candidate, checks both inputs and counts the
minimum-weight Pauli operators and the leading maximum-likelihood error
coefficients. Expected end of output:

    PASS. Both distances are 6. Leading coefficients: 171878/27 and 165228/27.
    Relative reduction: 475/12277 (3.869023377%).

`PROOF.md` gives the argument. The two check matrices and both sets of
counts are supplied. The replay verifies the pinned baseline Git blob and
the reconstructed candidate checks' SHA-256. Three negative controls
check a malformed row, an incorrect dimension and a forged failure count.

The baseline matrix comes from @hirobumii's qLDPC Challenge PR #3867 and
retains its Apache-2.0 license, supplied in `provenance/LICENSE`.
