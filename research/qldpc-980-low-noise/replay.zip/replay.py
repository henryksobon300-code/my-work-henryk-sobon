"""Replay the two 980-qubit CSS code calculations with Python 3.10+."""

import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
BASELINE_BLOB = "202238a380652df23d2b3b6c64265d9b1b2b0463"


def main():
    baseline = (ROOT / "provenance/980-398-6.json").read_bytes()
    git_blob = b"blob " + str(len(baseline)).encode() + b"\0" + baseline
    if hashlib.sha1(git_blob).hexdigest() != BASELINE_BLOB:
        raise ValueError("The baseline matrix differs from the pinned Git blob.")

    (ROOT / "results").mkdir(exist_ok=True)
    for name in ("build_and_census.py", "independent_verify.py", "negative_controls.py"):
        print(f"Running {name}", flush=True)
        subprocess.run([sys.executable, str(ROOT / "src" / name)], cwd=ROOT, check=True)

    candidate = json.loads((ROOT / "results/candidate_980_398_6.json").read_text())
    check_bytes = json.dumps(candidate["checks"], separators=(",", ":"), sort_keys=True).encode()
    if hashlib.sha256(check_bytes).hexdigest() != "a94c19ea622454d937a92919403952019aae439e90fba72673e867b35e054157":
        raise ValueError("The reconstructed matrices differ from the published candidate.")

    census = json.loads((ROOT / "results/candidate_comparison.json").read_text())
    audit = json.loads((ROOT / "results/independent_verification.json").read_text())
    controls = json.loads((ROOT / "results/negative_controls.json").read_text())
    for label, logicals, failures in (("baseline", 20027, 171878), ("candidate", 19110, 165228)):
        first = census[label]
        second = audit[label]
        for side in ("X", "Z"):
            for key in ("minimum_pure_logicals", "class_histogram", "unavoidable_weight3_failures"):
                if first[side][key] != second[side][key]:
                    raise ValueError(f"Disagreement for {label} {side} {key}")
        if second["total_weight6_Pauli_logicals"] != logicals:
            raise ValueError(f"Unexpected number of weight-six logicals for {label}")
        if second["leading_depolarizing_numerator"] != failures:
            raise ValueError(f"Unexpected number of unavoidable weight-three failures for {label}")
        if second["minimum_Pauli_distance"] != 6:
            raise ValueError(f"Unexpected distance for {label}")
    if not controls["ok"] or not all(controls["checks"].values()):
        raise ValueError("A negative control failed.")

    print("PASS. Both distances are 6. Leading coefficients: 171878/27 and 165228/27.")
    print("Relative reduction: 475/12277 (3.869023377%).")


if __name__ == "__main__":
    if not __debug__:
        raise SystemExit("Run without -O so the mathematical assertions are checked.")
    main()
