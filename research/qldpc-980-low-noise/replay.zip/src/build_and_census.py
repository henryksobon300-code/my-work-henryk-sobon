"""Construct a candidate and count weight-six logical operators/ambiguities."""
from collections import Counter,defaultdict
import itertools,json,hashlib
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
P,M,R=7,14,6
N=P*M
A=(7,22,40)
B=(7,23,38)


def product(x,y):return (x%P+pow(R,x//P,P)*(y%P))%P+P*((x//P+y//P)%M)
def inverse(g):return next(x for x in range(N) if product(g,x)==0)
def bitrow(row):return sum(1<<q for q in row)
def support(v):return [q for q in range(10*N) if v>>q&1]


def basis(rows):
    piv={};selected=[]
    for row in rows:
        x=row
        while x:
            k=x.bit_length()-1
            if k in piv:x^=piv[k]
            else:piv[k]=x;selected.append(row);break
    return piv,selected


def reduce(x,piv):
    while x:
        k=x.bit_length()-1
        if k not in piv:return x
        x^=piv[k]
    return 0


def construct():
    full={s:[] for s in ('X','Z')}
    for j,b in enumerate(B):
        for t in range(N):
            row=[N*(3*k+j)+u for k,a in enumerate(A) for u in (t,product(a,t))]
            row += [9*N+u for u in (t,product(t,b))]
            full['X'].append(bitrow(row))
    for k,a in enumerate(A):
        for t in range(N):
            row=[N*(3*k+j)+u for j,b in enumerate(B) for u in (t,product(t,inverse(b)))]
            row += [9*N+u for u in (t,product(inverse(a),t))]
            full['Z'].append(bitrow(row))
    checks={s:[support(x) for x in basis(rows)[1]] for s,rows in full.items()}
    assert all(len(rows)==3*(N-1) for rows in checks.values())
    assert all((x&z).bit_count()%2==0 for x in full['X'] for z in full['Z'])
    return {'schema_version':'0.1','name':'[[980,398,6]] lifted-product code with lower leading ML error',
      'code_type':'CSS','n':10*N,'k':10*N-sum(len(x) for x in checks.values()),'checks':checks,
      'distance':{'d':6},'family':'lifted-product',
      'provenance':{'authors':['@henryksobon300-code'],'date':'2026-10-29',
       'novelty':'known_parameters',
       'construction':f'G=C7 semidirect C14, index i+7*j; (i,j)(k,l)=(i+6^j*k mod7,j+l mod14). A generators {A}; B generators {B}. Nine VV(k,j) blocks indexed 3*k+j precede CC; each size98. Same lifted-product left/right convention as board code 980-398-6. Keep first independent natural rows.',
       'references':['https://arxiv.org/abs/2111.03654'],
       'notes':'Research instance with an author-side distance argument and reproducible Pauli counts.'}}


def full_rows(code,sector):
    n=code['n']//10;rows=[set(r) for r in code['checks'][sector]];out=[]
    assert len(rows)==3*(n-1)
    for k in range(3):
        block=rows[k*(n-1):(k+1)*(n-1)];last=set()
        for r in block:last.symmetric_difference_update(r)
        out.extend(block+[last])
    return out


def census(code,label):
    n=code['n']//10
    bases={s:basis([bitrow(x) for x in code['checks'][s]])[0] for s in ('X','Z')}
    results={};allcycles={}
    for error,opposite in [('X','Z'),('Z','X')]:
        rows=full_rows(code,opposite)
        columns=[set() for _ in range(10*n)]
        for r,row in enumerate(rows):
            for q in row:columns[q].add(r)
        qs=list(range(3*n)) if error=='X' else [n*(3*k)+u for k in range(3) for u in range(n)]
        adj=[{} for _ in range(n)]
        for q in qs:
            vertices=sorted(columns[q]);assert len(vertices)==2 and all(v<n for v in vertices)
            u,v=vertices;assert v not in adj[u]
            adj[u][v]=q;adj[v][u]=q
        cycles=set()
        for root in range(n):
            def dfs(path):
                v=path[-1]
                if len(path)==6:
                    if root in adj[v]:
                        edges=tuple(sorted(adj[path[i]][path[(i+1)%6]] for i in range(6)))
                        cycles.add(edges)
                    return
                for w in adj[v]:
                    if w>root and w not in path:dfs(path+[w])
            dfs([root])
        blocks=[]
        for block in range(3):
            shift=(3*n if error=='X' else n)*block
            blocks.extend(tuple(q+shift for q in cycle) for cycle in cycles)
        assert all(reduce(bitrow(s),bases[error]) for s in blocks),'weight-six stabilizer encountered'
        # One-CC supports were absent from the first, explicitly superseded
        # cycle-only comparison. Enumerate their VV paths independently here.
        extra=set()
        offsets=[block*(3*n if error=='X' else n) for block in range(3)]
        def paths_to(start,finish):
            answers=[]
            def walk(vertices,edges):
                u=vertices[-1]
                if u==finish:
                    answers.append(tuple(edges));return
                if len(edges)==3:return
                for v,q in adj[u].items():
                    if v not in vertices:walk(vertices+[v],edges+[q])
            walk([start],[])
            return answers
        for cc in range(n):
            choices=[]
            for block in range(3):
                ends=sorted(v%n for v in columns[9*n+cc] if v//n==block)
                assert len(ends)==2
                choices.append(paths_to(*ends))
            for paths in itertools.product(*choices):
                if sum(map(len,paths))!=5:continue
                operator=tuple(sorted([9*n+cc]+[q+offsets[b] for b,path in enumerate(paths) for q in path]))
                assert len(set(operator))==6
                assert reduce(bitrow(operator),bases[error])
                extra.add(operator)
        vv_count=len(blocks)
        blocks=sorted(set(blocks)|extra)
        # Reconstruct genuine syndromes in the full presentation.
        boundary=[bitrow(c) for c in columns]
        triples={t for c in blocks for t in itertools.combinations(c,3)}
        groups=defaultdict(list)
        for triple in sorted(triples):
            syn=boundary[triple[0]]^boundary[triple[1]]^boundary[triple[2]]
            groups[syn].append(triple)
        hist=Counter(map(len,groups.values()));assert min(hist)>=2
        assert sum(r*(r-1)//2*c for r,c in hist.items())==10*len(blocks)
        results[error]={'cycles_per_block':len(cycles),'minimum_pure_logicals':len(blocks),
           'VV_six_cycle_logicals':vv_count,'one_CC_six_logicals':len(extra),
           'ambiguous_weight3_patterns':len(triples),'ambiguous_syndromes':len(groups),
           'class_histogram':dict(sorted(hist.items())),
           'unavoidable_weight3_failures':len(triples)-len(groups)}
        allcycles[error]=sorted(blocks)
    assert not(set(allcycles['X'])&set(allcycles['Z'])),'mixed Pauli support possible'
    results['total_weight6_pure_logicals']=sum(x['minimum_pure_logicals'] for x in results.values())
    results['leading_depolarizing_numerator']=sum(results[s]['unavoidable_weight3_failures'] for s in ('X','Z'))
    results['leading_depolarizing_denominator']=27
    (ROOT/'results'/f'{label}_cycles.json').write_text(json.dumps(allcycles,separators=(',',':'))+'\n')
    return results,allcycles


def main():
    code=construct()
    candidate,cycles=census(code,'candidate')
    for side in ('X','Z'):
        code['distance'][side]={'value':6,'confidence':'upper_bound','witness':cycles[side][0]}
    (ROOT/'results/candidate_980_398_6.json').write_text(json.dumps(code,indent=2)+'\n')
    parent=json.loads((ROOT/'provenance/980-398-6.json').read_text())
    baseline,_=census(parent,'baseline')
    result={'baseline':baseline,'candidate':candidate,
        'minimum_logical_reduction':baseline['total_weight6_pure_logicals']-candidate['total_weight6_pure_logicals'],
        'leading_numerator_reduction':baseline['leading_depolarizing_numerator']-candidate['leading_depolarizing_numerator']}
    (ROOT/'results/candidate_comparison.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
