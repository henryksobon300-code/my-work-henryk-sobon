"""Independent matrix-only audit. Standard library; no producer/engine imports.

The input is the stored sparse parity-check matrices, not the construction
parameters or producer cycle lists. See PROOF.md for the finite-support lemma.
"""
from collections import Counter, defaultdict, deque
from fractions import Fraction
from itertools import combinations, product
from pathlib import Path
import gc
import json
import math
import sys
import time

ROOT = Path(__file__).resolve().parent.parent


def mask(items):
    answer = 0
    for i in items:
        answer ^= 1 << i
    return answer


def echelon(rows):
    """Use LOW pivots, independently of the producer's HIGH pivots."""
    pivots = {}
    for value in rows:
        while value:
            p = value & -value
            if p not in pivots:
                pivots[p] = value
                break
            value ^= pivots[p]
    return pivots


def remainder(value, pivots):
    while value:
        p = value & -value
        if p not in pivots:
            return value
        value ^= pivots[p]
    return 0


def expand(code, side):
    size = code['n'] // 10
    rows = code['checks'][side]
    assert len(rows) == 3 * (size - 1)
    stored = []
    for row in rows:
        assert row == sorted(set(row)) and all(0 <= q < code['n'] for q in row)
        stored.append(mask(row))
    full = []
    for block in range(3):
        part = stored[block * (size - 1):(block + 1) * (size - 1)]
        missing = 0
        for row in part:
            missing ^= row
        full.extend(part + [missing])
    pivots = echelon(stored)
    assert len(pivots) == len(stored)
    assert all(remainder(row, pivots) == 0 for row in full)
    assert len(echelon(full)) == len(pivots)
    assert all(row.bit_count() == 8 for row in full)
    return full, pivots


def bfs(adjacency, start):
    distances = [-1] * len(adjacency)
    distances[start] = 0
    queue = deque([start])
    while queue:
        u = queue.popleft()
        for v in adjacency[u]:
            if distances[v] < 0:
                distances[v] = distances[u] + 1
                queue.append(v)
    assert -1 not in distances
    return distances


def graph_cycles(edges, size):
    """Meet two simple paths of length three; no producer DFS is reused."""
    adjacency = [dict() for _ in range(size)]
    for u, v, q in edges:
        assert u != v and v not in adjacency[u]
        adjacency[u][v] = q
        adjacency[v][u] = q
    assert all(len(row) == 6 for row in adjacency)
    all_distances = [bfs(adjacency, u) for u in range(size)]
    # Girth >= 6: for each edge remove it and rule out paths of length <= 4.
    shortest_cycle = size + 1
    for u, v, _ in edges:
        dist = {u: 0}
        queue = deque([u])
        while queue:
            a = queue.popleft()
            if dist[a] >= 5:
                continue
            for b in adjacency[a]:
                if {a, b} == {u, v}:
                    continue
                if b not in dist:
                    dist[b] = dist[a] + 1
                    queue.append(b)
        if v in dist:
            shortest_cycle = min(shortest_cycle, 1 + dist[v])
    assert shortest_cycle == 6
    cycles = set()
    for start in range(size):
        paths = defaultdict(list)
        for u in adjacency[start]:
            for v in adjacency[u]:
                if v == start:
                    continue
                for finish in adjacency[v]:
                    if finish in (start, u):
                        continue
                    paths[finish].append((u, v))
        for finish, pairs in paths.items():
            for (a, b), (c, d) in combinations(pairs, 2):
                if len({start, a, b, finish, d, c}) == 6:
                    cycle = tuple(sorted((adjacency[start][a], adjacency[a][b],
                                          adjacency[b][finish], adjacency[finish][d],
                                          adjacency[d][c], adjacency[c][start])))
                    assert len(set(cycle)) == 6
                    cycles.add(cycle)
    return adjacency, all_distances, cycles


def all_triples(edges):
    """Count EVERY three-edge set, not only halves of supplied cycles."""
    boundaries = [(1 << u) ^ (1 << v) for u, v, _ in edges]
    counts = {}
    length = len(boundaries)
    for a in range(length - 2):
        for b in range(a + 1, length - 1):
            first = boundaries[a] ^ boundaries[b]
            for c in range(b + 1, length):
                syndrome = first ^ boundaries[c]
                counts[syndrome] = counts.get(syndrome, 0) + 1
    assert 0 not in counts
    assert sum(counts.values()) == math.comb(length, 3)
    histogram = Counter(count for count in counts.values() if count > 1)
    del counts
    gc.collect()
    return histogram


def shortest_paths(adjacency, distances, start, finish):
    paths = []
    def visit(u, edges):
        if u == finish:
            paths.append(tuple(edges))
            return
        for v, q in adjacency[u].items():
            if distances[v][finish] == distances[u][finish] - 1:
                visit(v, edges + [q])
    visit(start, [])
    return paths


def inspect_sector(code, rows, stabilizer_pivots, error_side):
    size = code['n'] // 10
    columns = [[] for _ in range(code['n'])]
    for row_index, row in enumerate(rows):
        for q in range(code['n']):
            if (row >> q) & 1:
                columns[q].append(row_index)
    graphs = [[] for _ in range(3)]
    for q in range(9 * size):
        assert len(columns[q]) == 2
        a, b = columns[q]
        assert a // size == b // size
        graphs[a // size].append((a % size, b % size, q))
    assert all(len(graph) == 3 * size for graph in graphs)
    permutations = [[] for _ in range(3)]
    for u in range(size):
        support = columns[9 * size + u]
        assert len(support) == 6
        for block in range(3):
            endpoints = [v % size for v in support if v // size == block]
            assert len(endpoints) == 2 and u in endpoints
            endpoints.remove(u)
            permutations[block].append(endpoints[0])
    action_edges = []
    cycle_lengths = []
    for permutation in permutations:
        assert sorted(permutation) == list(range(size))
        lengths = []
        unseen = set(range(size))
        while unseen:
            start = min(unseen)
            u = start
            length = 0
            while u in unseen:
                unseen.remove(u)
                length += 1
                u = permutation[u]
            assert u == start
            lengths.append(length)
        assert min(lengths) > 6
        cycle_lengths.append(sorted(lengths))
        action_edges.append({frozenset((u, v)) for u, v in enumerate(permutation)})
    assert all(not (a & b) for a, b in combinations(action_edges, 2))
    distances = []
    adjacencies = []
    logical_cycles = set()
    representative = None
    representative_count = None
    for block, graph in enumerate(graphs):
        adjacency, distance, cycles = graph_cycles(graph, size)
        adjacencies.append(adjacency)
        distances.append(distance)
        shift = block * (3 * size if error_side == 'X' else size)
        normalized = [(u, v, q - shift) for u, v, q in graph]
        if block == 0:
            representative = normalized
            representative_count = len(cycles)
        else:
            assert normalized == representative
            assert len(cycles) == representative_count
        for cycle in cycles:
            assert remainder(mask(cycle), stabilizer_pivots) != 0
            logical_cycles.add(cycle)
    one_cc_costs = [sum(distances[block][u][permutations[block][u]]
                        for block in range(3)) for u in range(size)]
    print('  one-CC VV distance range:', min(one_cc_costs), max(one_cc_costs), flush=True)
    assert min(one_cc_costs) >= 5  # Exclude weight <= 5; classify equality below.
    one_cc_operators = set()
    for u, cost in enumerate(one_cc_costs):
        if cost != 5:
            continue
        paths = [shortest_paths(adjacencies[block], distances[block], u,
                                permutations[block][u]) for block in range(3)]
        for combination in product(*paths):
            operator = tuple(sorted([9 * size + u] + [q for path in combination for q in path]))
            assert len(operator) == 6 and len(set(operator)) == 6
            assert remainder(mask(operator), stabilizer_pivots) != 0
            one_cc_operators.add(operator)
    logical_operators = logical_cycles | one_cc_operators
    print('  additional one-CC weight-six logicals:', len(one_cc_operators), flush=True)
    print('  full triples census:', error_side, flush=True)
    histogram = all_triples(graphs[0])
    histogram = {int(k): 3 * int(v) for k, v in sorted(histogram.items())}
    collision_pairs = sum(k * (k - 1) // 2 * v for k, v in histogram.items())
    assert collision_pairs == 10 * len(logical_cycles)
    # Independently enumerated operators now include the one-CC family.
    # First cross-check the pure-cycle half census against ALL graph triples.
    boundaries = [mask(column) for column in columns]
    def half_groups(operators):
        triples = set(t for operator in operators for t in combinations(operator, 3))
        groups = defaultdict(list)
        for triple in triples:
            syndrome = boundaries[triple[0]] ^ boundaries[triple[1]] ^ boundaries[triple[2]]
            groups[syndrome].append(triple)
        return groups
    cycle_groups = half_groups(logical_cycles)
    assert dict(sorted(Counter(map(len, cycle_groups.values())).items())) == histogram
    groups = half_groups(logical_operators)
    histogram = dict(sorted(Counter(map(len, groups.values())).items()))
    assert min(histogram) >= 2
    # Test every collision: disjoint support; difference a classified logical.
    pair_count = 0
    for members in groups.values():
        for a, b in combinations(members, 2):
            assert not (set(a) & set(b))
            assert tuple(sorted(a + b)) in logical_operators
            pair_count += 1
    assert pair_count == 10 * len(logical_operators)
    ambiguous_patterns = sum(k * v for k, v in histogram.items())
    ambiguous_syndromes = sum(histogram.values())
    return {
        'cycles_per_block': representative_count,
        'minimum_pure_logicals': len(logical_operators),
        'VV_six_cycle_logicals': len(logical_cycles),
        'one_CC_six_logicals': len(one_cc_operators),
        'ambiguous_weight3_patterns': ambiguous_patterns,
        'ambiguous_syndromes': ambiguous_syndromes,
        'class_histogram': histogram,
        'unavoidable_weight3_failures': ambiguous_patterns - ambiguous_syndromes,
        'minimum_one_CC_VV_cost': min(one_cc_costs),
        'CC_permutation_cycle_lengths': cycle_lengths,
        'representative_triples_checked': math.comb(3 * size, 3),
        'minimum_pure_distance': 6,
        'weight_le_6_stabilizers': 0,
    }, logical_operators


def inspect(path):
    code = json.loads(path.read_text())
    assert code['n'] == 980 and code['k'] == 398
    full = {}
    pivots = {}
    for side in ('X', 'Z'):
        full[side], pivots[side] = expand(code, side)
    assert code['n'] - sum(map(len, pivots.values())) == code['k']
    assert all((x & z).bit_count() % 2 == 0 for x in full['X'] for z in full['Z'])
    results = {}
    cycles = {}
    for error_side, check_side in (('X', 'Z'), ('Z', 'X')):
        results[error_side], cycles[error_side] = inspect_sector(
            code, full[check_side], pivots[error_side], error_side)
        witness = code['distance'][error_side]['witness']
        assert len(witness) == 6 and tuple(sorted(witness)) in cycles[error_side]
    assert not (cycles['X'] & cycles['Z'])
    results['minimum_Pauli_distance'] = 6
    results['total_weight6_Pauli_logicals'] = sum(len(v) for v in cycles.values())
    results['mixed_weight6_Pauli_logicals'] = 0
    results['leading_depolarizing_numerator'] = sum(
        results[s]['unavoidable_weight3_failures'] for s in ('X', 'Z'))
    results['leading_depolarizing_denominator'] = 27
    results['ranks'] = {s: len(pivots[s]) for s in ('X', 'Z')}
    results['max_check_weight'] = 8
    return results


def main():
    started = time.monotonic()
    results = {}
    for label, filename in (('baseline', 'provenance/980-398-6.json'),
                            ('candidate', 'results/candidate_980_398_6.json')):
        print('Independent matrix audit:', label, flush=True)
        results[label] = inspect(ROOT / filename)
    old = results['baseline']['leading_depolarizing_numerator']
    new = results['candidate']['leading_depolarizing_numerator']
    assert new < old
    ratio = Fraction(old - new, old)
    results['relative_leading_coefficient_reduction'] = {
        'numerator': ratio.numerator, 'denominator': ratio.denominator,
        'percent': float(ratio * 100)}
    assert results['baseline']['total_weight6_Pauli_logicals'] != results['candidate']['total_weight6_Pauli_logicals']
    results['inequivalent_under_local_Clifford_and_permutation'] = True
    results['method'] = 'Independent low-pivot GF2; matrices only; meet-of-three-paths cycles; exhaustive ALL edge triples; finite-support lemma in PROOF.md.'
    results['elapsed_seconds'] = round(time.monotonic() - started, 3)
    results['ok'] = True
    (ROOT / 'results/independent_verification.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(results, indent=2))


if __name__ == '__main__':
    main()
