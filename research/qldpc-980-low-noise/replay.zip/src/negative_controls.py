"""Meaningful rejection checks; never alter archived inputs in place."""
from pathlib import Path
import copy
import json
import sys

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'src'))
from independent_verify import expand, inspect


def main():
    doc = json.loads((ROOT / 'results/candidate_980_398_6.json').read_text())
    corrupted = copy.deepcopy(doc)
    corrupted['checks']['X'][0].append(corrupted['checks']['X'][0][0])
    try:
        expand(corrupted, 'X')
    except AssertionError:
        duplicate_rejected = True
    else:
        raise AssertionError('duplicated check index was accepted')
    # Wrong dimension is rejected before any expensive census.
    corrupted = copy.deepcopy(doc)
    corrupted['k'] += 1
    path = ROOT / 'results/.negative_wrong_dimension.json'
    path.write_text(json.dumps(corrupted))
    try:
        try:
            inspect(path)
        except AssertionError:
            dimension_rejected = True
        else:
            raise AssertionError('wrong dimension was accepted')
    finally:
        path.unlink()
    # Audit reported numbers by their mathematical counting identity, then
    # reject a forged final coefficient with otherwise unchanged evidence.
    producer = json.loads((ROOT / 'results/candidate_comparison.json').read_text())
    independent = json.loads((ROOT / 'results/independent_verification.json').read_text())
    def check_counts(report):
        total = 0
        for side in ('X', 'Z'):
            histogram = report[side]['class_histogram']
            failures = sum((int(r) - 1) * count for r, count in histogram.items())
            assert failures == report[side]['unavoidable_weight3_failures']
            total += failures
        assert total == report['leading_depolarizing_numerator']
    for label in ('baseline', 'candidate'):
        check_counts(producer[label])
        check_counts(independent[label])
    forged = copy.deepcopy(independent['candidate'])
    forged['leading_depolarizing_numerator'] += 1
    try:
        check_counts(forged)
    except AssertionError:
        coefficient_rejected = True
    else:
        raise AssertionError('forged coefficient was accepted')
    checks = {'duplicate_check_index_rejected': duplicate_rejected,
              'wrong_dimension_rejected': dimension_rejected,
              'changed_coefficient_rejected_by_counting_identity': coefficient_rejected}
    report = {'ok': all(checks.values()), 'checks': checks}
    (ROOT / 'results/negative_controls.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report))


if __name__ == '__main__':
    main()
